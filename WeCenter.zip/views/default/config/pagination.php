<?php

$config = array(
	'first_link' => '&lt;&lt;',
	'next_link' => '&gt;',
	'prev_link' => '&lt;',
	'last_link' => '&gt;&gt;',
	'uri_segment' => 3,
	'full_tag_open' => '<div class="page-control"><ul class="pagination pull-right">',
	'full_tag_close' => '</ul></div>',
	'first_tag_open' => '<li>',
	'first_tag_close' => '</li>',
	'last_tag_open' => '<li>',
	'last_tag_close' => '</li>',
	'first_url' => '', // Alternative URL for the First Page.
	'cur_tag_open' => '<li class="active"><a href="javascript:;">',
	'cur_tag_close' => '</a></li>',
	'next_tag_open' => '<li>',
	'next_tag_close' => '</li>',
	'prev_tag_open' => '<li>',
	'prev_tag_close' => '</li>',
	'num_tag_open' => '<li>',
	'num_tag_close' => '</li>',
	'display_pages' => TRUE,
	'anchor_class' => '',
	'num_links' => 3
);